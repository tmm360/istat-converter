﻿namespace Istat
{
    class IstatCsvOutput
    {
        public int DateInSeconds { get; set; }
        public int AgeClass { get; set; }
        public string RegionName { get; set; }
        public int TotalDeaths { get; set; }
    }
}
