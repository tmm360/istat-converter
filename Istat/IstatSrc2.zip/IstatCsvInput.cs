﻿namespace Istat
{
    class IstatCsvInput
    {
        public string NOME_REGIONE { get; set; }
        public string NOME_PROVINCIA { get; set; }
        public string NOME_COMUNE { get; set; }
        public string CL_ETA { get; set; }
        public string GE { get; set; }
        public string T_15 { get; set; }
        public string T_16 { get; set; }
        public string T_17 { get; set; }
        public string T_18 { get; set; }
        public string T_19 { get; set; }
        public string T_20 { get; set; }
    }
}
